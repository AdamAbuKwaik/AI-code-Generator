import openai

def ai_code_suggestion(prompt):
    """Simulates AI-powered code suggestion."""
    response = f"Suggested code for: {prompt}"
    return response

if __name__ == "__main__":
    user_input = input("Enter your code idea: ")
    print(ai_code_suggestion(user_input))
